import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Service } from '../types';
import ServiceCard from '../components/ServiceCard';

const ServiceDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [service, setService] = useState<Service | null>(null);

  useEffect(() => {
    fetch(`/api/service/${id}`)
      .then(res => res.json())
      .then(setService)
      .catch(() => {
        // fallback
        setService({
          id: parseInt(id || '0'),
          title: 'Ошибка',
          description: 'Не удалось загрузить данные.',
          price: 0,
          date: '',
          imageUrl: ''
        });
      });
  }, [id]);

  if (!service) return <div>Загрузка...</div>;

  return (
    <>
      <h2>Детали услуги</h2>
      <ServiceCard {...service} />
    </>
  );
};

export default ServiceDetailPage;